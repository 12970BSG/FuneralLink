import { useState, useEffect } from "react";

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const MOCK_SUPPLIERS = [
  {
    id: "s1", name: "Prestige Tents & Marquees", type: "supplier",
    services: ["Tents", "Marquees", "Flooring"],
    area: "Johannesburg", rating: 4.8, reviews: 42,
    priceFrom: 3500, avatar: "PT",
    distance: 4.2, available: true,
    description: "Premium marquee solutions for dignified gatherings.",
  },
  {
    id: "s2", name: "Grace Catering Co.", type: "supplier",
    services: ["Catering", "Refreshments", "Waiting Staff"],
    area: "Johannesburg", rating: 4.6, reviews: 67,
    priceFrom: 8000, avatar: "GC",
    distance: 6.8, available: true,
    description: "Respectful catering services tailored to memorial events.",
  },
  {
    id: "s3", name: "SaniServ Solutions", type: "supplier",
    services: ["Portable Toilets", "Handwashing Stations", "Luxury Units"],
    area: "Johannesburg", rating: 4.5, reviews: 29,
    priceFrom: 1200, avatar: "SS",
    distance: 8.1, available: true,
    description: "Discreet sanitation hire for outdoor events.",
  },
  {
    id: "s4", name: "Serenity Chairs & Tables", type: "supplier",
    services: ["Chairs", "Tables", "Linen"],
    area: "Johannesburg", rating: 4.9, reviews: 54,
    priceFrom: 2200, avatar: "SC",
    distance: 3.5, available: false,
    description: "Full furniture hire for all sizes of gatherings.",
  },
  {
    id: "s5", name: "Bloom Floral Events", type: "supplier",
    services: ["Floral Arrangements", "Décor", "Wreaths"],
    area: "Johannesburg", rating: 4.7, reviews: 38,
    priceFrom: 4500, avatar: "BF",
    distance: 5.0, available: true,
    description: "Tasteful floral décor that honours the departed.",
  },
];

const MOCK_EVENTS = [
  {
    id: "e1", parlorId: "p1",
    name: "Memorial – M. Dlamini",
    date: "2025-03-22", location: "Soweto, Johannesburg",
    attendees: 120, needs: ["Tents", "Catering", "Portable Toilets"],
    status: "confirmed", budget: 18000,
  },
  {
    id: "e2", parlorId: "p1",
    name: "Graveside Service – T. Mokoena",
    date: "2025-03-29", location: "Sandton, Johannesburg",
    attendees: 60, needs: ["Tents", "Chairs"],
    status: "pending", budget: 9000,
  },
];

// ─── ICONS ───────────────────────────────────────────────────────────────────
const Icon = ({ d, size = 20, stroke = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

const Icons = {
  home: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 22V12h6v10",
  calendar: "M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z",
  users: "M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75",
  map: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z M12 10a1 1 0 100-2 1 1 0 000 2",
  check: "M20 6L9 17l-5-5",
  plus: "M12 5v14M5 12h14",
  star: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  bolt: "M13 2L3 14h9l-1 8 10-12h-9l1-8z",
  credit: "M1 4h22v16H1zM1 10h22",
  logout: "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9",
  truck: "M1 3h15v13H1zM16 8h4l3 3v5h-7V8zM5.5 19a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM18.5 19a1.5 1.5 0 100-3 1.5 1.5 0 000 3z",
  bell: "M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0",
  eye: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 12a3 3 0 100-6 3 3 0 000 6",
  x: "M18 6L6 18M6 6l12 12",
  arrow: "M5 12h14M12 5l7 7-7 7",
};

// ─── THEME TOKENS ─────────────────────────────────────────────────────────────
const T = {
  bg: "#0D0F0E",
  surface: "#151918",
  surfaceHover: "#1C2120",
  border: "#252B29",
  borderLight: "#2E3633",
  accent: "#C8A97E",         // warm gold
  accentDim: "#A88A62",
  accentGlow: "rgba(200,169,126,0.12)",
  green: "#4CAF7D",
  greenDim: "rgba(76,175,125,0.15)",
  red: "#E07070",
  redDim: "rgba(224,112,112,0.15)",
  blue: "#6BA3C8",
  text: "#E8E4DC",
  textMid: "#9DA89F",
  textDim: "#5A6360",
};

// ─── GLOBAL STYLES ────────────────────────────────────────────────────────────
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500&display=swap');
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html, body, #root { height: 100%; background: ${T.bg}; color: ${T.text}; font-family: 'DM Sans', sans-serif; }
    ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: ${T.border}; border-radius: 2px; }
    input, select, textarea { font-family: 'DM Sans', sans-serif; }
    button { cursor: pointer; font-family: 'DM Sans', sans-serif; }
    @keyframes fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
    @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
    @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:.4; } }
    .fade-up { animation: fadeUp 0.45s cubic-bezier(.22,.68,0,1.2) both; }
    .fade-in { animation: fadeIn 0.3s ease both; }
  `}</style>
);

// ─── PRIMITIVE COMPONENTS ────────────────────────────────────────────────────
const Badge = ({ children, color = T.accent, bg }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 4,
    padding: "2px 10px", borderRadius: 99, fontSize: 11, fontWeight: 500,
    letterSpacing: "0.04em", textTransform: "uppercase",
    color, background: bg || `${color}20`, border: `1px solid ${color}30`,
  }}>{children}</span>
);

const Btn = ({ children, variant = "primary", onClick, small, disabled, icon, style: s }) => {
  const styles = {
    primary: { bg: T.accent, color: "#0D0F0E", border: "none" },
    secondary: { bg: "transparent", color: T.text, border: `1px solid ${T.border}` },
    ghost: { bg: "transparent", color: T.textMid, border: "none" },
    danger: { bg: T.redDim, color: T.red, border: `1px solid ${T.red}30` },
  };
  const v = styles[variant];
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: small ? "6px 14px" : "10px 20px",
      borderRadius: 8, fontSize: small ? 12 : 14, fontWeight: 500,
      background: v.bg, color: v.color, border: v.border,
      opacity: disabled ? 0.45 : 1,
      transition: "all 0.18s ease",
      ...s
    }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.opacity = "0.82"; }}
      onMouseLeave={e => { e.currentTarget.style.opacity = disabled ? "0.45" : "1"; }}
    >
      {icon && icon}{children}
    </button>
  );
};

const Card = ({ children, style: s, className }) => (
  <div className={className} style={{
    background: T.surface, border: `1px solid ${T.border}`,
    borderRadius: 12, padding: 24, ...s
  }}>{children}</div>
);

const Input = ({ label, type = "text", value, onChange, placeholder, options, required }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
    {label && <label style={{ fontSize: 12, color: T.textMid, letterSpacing: "0.05em", textTransform: "uppercase" }}>
      {label}{required && <span style={{ color: T.accent }}> *</span>}
    </label>}
    {options ? (
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        background: T.surfaceHover, border: `1px solid ${T.borderLight}`,
        borderRadius: 8, padding: "10px 14px", color: T.text, fontSize: 14,
        outline: "none", appearance: "none",
      }}>
        {options.map(o => <option key={o.value || o} value={o.value || o}>{o.label || o}</option>)}
      </select>
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{
          background: T.surfaceHover, border: `1px solid ${T.borderLight}`,
          borderRadius: 8, padding: "10px 14px", color: T.text, fontSize: 14,
          outline: "none",
        }}
        onFocus={e => e.target.style.borderColor = T.accent}
        onBlur={e => e.target.style.borderColor = T.borderLight}
      />
    )}
  </div>
);

const Stat = ({ label, value, sub, accent }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
    <span style={{ fontSize: 11, color: T.textDim, textTransform: "uppercase", letterSpacing: "0.07em" }}>{label}</span>
    <span style={{ fontSize: 26, fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, color: accent || T.text, lineHeight: 1.1 }}>{value}</span>
    {sub && <span style={{ fontSize: 11, color: T.textMid }}>{sub}</span>}
  </div>
);

const Divider = ({ style: s }) => <div style={{ height: 1, background: T.border, ...s }} />;

// ─── SIDEBAR NAV ─────────────────────────────────────────────────────────────
const Sidebar = ({ user, page, setPage, onLogout }) => {
  const isSupplier = user?.type === "supplier";
  const navItems = isSupplier
    ? [
        { key: "dashboard", label: "Dashboard", icon: Icons.home },
        { key: "listings", label: "My Listings", icon: Icons.truck },
        { key: "bookings", label: "Bookings", icon: Icons.calendar },
      ]
    : [
        { key: "dashboard", label: "Dashboard", icon: Icons.home },
        { key: "events", label: "My Events", icon: Icons.calendar },
        { key: "match", label: "Find Suppliers", icon: Icons.bolt },
        { key: "bookings", label: "Bookings", icon: Icons.users },
      ];

  return (
    <aside style={{
      width: 220, minHeight: "100vh", background: T.surface,
      borderRight: `1px solid ${T.border}`,
      display: "flex", flexDirection: "column",
      position: "fixed", top: 0, left: 0, zIndex: 10,
    }}>
      {/* Logo */}
      <div style={{ padding: "28px 24px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: T.accent, display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <span style={{ fontSize: 16, color: "#0D0F0E" }}>◆</span>
          </div>
          <div>
            <div style={{ fontSize: 15, fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, letterSpacing: "0.02em", color: T.text }}>FuneralLink</div>
            <div style={{ fontSize: 10, color: T.textDim, letterSpacing: "0.08em", textTransform: "uppercase" }}>Event Connect</div>
          </div>
        </div>
      </div>

      <Divider />

      {/* User pill */}
      <div style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: T.bg, borderRadius: 8 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 6, background: T.accentGlow,
            border: `1px solid ${T.accent}40`, display: "flex", alignItems: "center",
            justifyContent: "center", fontSize: 13, fontWeight: 600, color: T.accent,
          }}>{user?.name?.[0]}</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500, color: T.text, lineHeight: 1.2 }}>{user?.name}</div>
            <div style={{ fontSize: 10, color: T.textDim, textTransform: "capitalize" }}>{user?.type}</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "4px 12px" }}>
        {navItems.map(({ key, label, icon }) => {
          const active = page === key;
          return (
            <button key={key} onClick={() => setPage(key)} style={{
              width: "100%", display: "flex", alignItems: "center", gap: 10,
              padding: "9px 12px", borderRadius: 8, border: "none", textAlign: "left",
              background: active ? T.accentGlow : "transparent",
              color: active ? T.accent : T.textMid,
              fontSize: 13, fontWeight: active ? 500 : 400,
              marginBottom: 2, transition: "all 0.15s",
            }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = T.surfaceHover; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}
            >
              <Icon d={icon} size={16} />
              {label}
              {active && <div style={{ marginLeft: "auto", width: 4, height: 4, borderRadius: 2, background: T.accent }} />}
            </button>
          );
        })}
      </nav>

      <Divider />
      <button onClick={onLogout} style={{
        display: "flex", alignItems: "center", gap: 8, padding: "16px 24px",
        background: "none", border: "none", color: T.textDim, fontSize: 13,
      }}>
        <Icon d={Icons.logout} size={15} /> Sign out
      </button>
    </aside>
  );
};

// ─── AUTH SCREEN ─────────────────────────────────────────────────────────────
const AuthScreen = ({ onLogin }) => {
  const [mode, setMode] = useState("login");
  const [role, setRole] = useState("parlor");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const handleSubmit = () => {
    if (!email) return;
    onLogin({
      id: "u1",
      name: name || (role === "parlor" ? "Serenity Funeral Home" : "Prestige Tents"),
      email,
      type: role,
    });
  };

  return (
    <div style={{
      minHeight: "100vh", background: T.bg,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24,
    }}>
      <GlobalStyle />
      {/* Background texture */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none",
        background: `radial-gradient(ellipse 60% 40% at 50% 0%, ${T.accentGlow} 0%, transparent 70%)`,
      }} />

      <div className="fade-up" style={{ width: "100%", maxWidth: 420, zIndex: 1 }}>
        {/* Brand */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14, background: T.accent,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 24, margin: "0 auto 16px",
          }}>◆</div>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, fontWeight: 600, letterSpacing: "0.01em", marginBottom: 6 }}>FuneralLink</h1>
          <p style={{ color: T.textMid, fontSize: 14 }}>Connecting parlors with trusted local suppliers</p>
        </div>

        <Card>
          {/* Tabs */}
          <div style={{ display: "flex", background: T.bg, borderRadius: 8, padding: 4, marginBottom: 24 }}>
            {["login", "register"].map(t => (
              <button key={t} onClick={() => setMode(t)} style={{
                flex: 1, padding: "8px 0", borderRadius: 6, border: "none", fontSize: 13,
                background: mode === t ? T.surface : "transparent",
                color: mode === t ? T.text : T.textMid,
                fontWeight: mode === t ? 500 : 400,
                transition: "all 0.15s",
              }}>{t === "login" ? "Sign In" : "Register"}</button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Role selector */}
            <div>
              <label style={{ fontSize: 12, color: T.textMid, letterSpacing: "0.05em", textTransform: "uppercase", display: "block", marginBottom: 8 }}>I am a</label>
              <div style={{ display: "flex", gap: 8 }}>
                {[{ val: "parlor", label: "Funeral Parlor" }, { val: "supplier", label: "Supplier" }].map(r => (
                  <button key={r.val} onClick={() => setRole(r.val)} style={{
                    flex: 1, padding: "10px 0", borderRadius: 8, fontSize: 13, fontWeight: 500,
                    background: role === r.val ? T.accentGlow : T.surfaceHover,
                    color: role === r.val ? T.accent : T.textMid,
                    border: `1px solid ${role === r.val ? T.accent + "60" : T.border}`,
                    transition: "all 0.15s",
                  }}>{r.label}</button>
                ))}
              </div>
            </div>

            {mode === "register" && <Input label="Business Name" value={name} onChange={setName} placeholder="e.g. Serenity Funeral Home" required />}
            <Input label="Email Address" type="email" value={email} onChange={setEmail} placeholder="you@business.co.za" required />
            <Input label="Password" type="password" value={pass} onChange={setPass} placeholder="••••••••" required />

            <Btn onClick={handleSubmit} style={{ width: "100%", justifyContent: "center", marginTop: 4 }}>
              {mode === "login" ? "Sign In" : "Create Account"}
              <Icon d={Icons.arrow} size={15} />
            </Btn>
          </div>
        </Card>

        <p style={{ textAlign: "center", marginTop: 20, fontSize: 12, color: T.textDim }}>
          Demo: click Sign In to enter the prototype
        </p>
      </div>
    </div>
  );
};

// ─── PARLOR DASHBOARD ─────────────────────────────────────────────────────────
const ParlorDashboard = ({ user, setPage }) => {
  const upcomingCount = MOCK_EVENTS.length;
  const pendingCount = MOCK_EVENTS.filter(e => e.status === "pending").length;
  const totalSpend = MOCK_EVENTS.reduce((s, e) => s + e.budget, 0);

  return (
    <div className="fade-up">
      <div style={{ marginBottom: 32 }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 4 }}>Good morning, {user.name}</h2>
        <p style={{ color: T.textMid, fontSize: 14 }}>Here's an overview of your upcoming events.</p>
      </div>

      {/* Stats row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }}>
        {[
          { label: "Upcoming Events", value: upcomingCount, sub: "Next 30 days", accent: T.text },
          { label: "Pending Bookings", value: pendingCount, sub: "Awaiting suppliers", accent: T.accent },
          { label: "Projected Spend", value: `R${totalSpend.toLocaleString()}`, sub: "Across all events", accent: T.green },
        ].map((s, i) => (
          <Card key={i} style={{ padding: 20 }}>
            <Stat {...s} />
          </Card>
        ))}
      </div>

      {/* Events table */}
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 600 }}>Active Events</h3>
          <Btn small onClick={() => setPage("events")} variant="secondary" icon={<Icon d={Icons.arrow} size={13} />}>View All</Btn>
        </div>
        {MOCK_EVENTS.map((ev, i) => (
          <div key={ev.id}>
            {i > 0 && <Divider style={{ margin: "12px 0" }} />}
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{
                width: 42, height: 42, borderRadius: 8,
                background: ev.status === "confirmed" ? T.greenDim : T.accentGlow,
                border: `1px solid ${ev.status === "confirmed" ? T.green + "40" : T.accent + "40"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <Icon d={Icons.calendar} size={18} stroke={ev.status === "confirmed" ? T.green : T.accent} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 2 }}>{ev.name}</div>
                <div style={{ fontSize: 12, color: T.textMid }}>{ev.date} · {ev.location} · {ev.attendees} attendees</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <Badge color={ev.status === "confirmed" ? T.green : T.accent}>
                  {ev.status}
                </Badge>
                <div style={{ fontSize: 12, color: T.textMid, marginTop: 4 }}>R{ev.budget.toLocaleString()}</div>
              </div>
            </div>
          </div>
        ))}
      </Card>

      {/* Quick action */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Card style={{ cursor: "pointer", transition: "border-color 0.2s" }}
          className=""
          onClick={() => setPage("events")}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 40, height: 40, borderRadius: 8, background: T.accentGlow, border: `1px solid ${T.accent}40`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon d={Icons.plus} size={18} stroke={T.accent} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500 }}>Create New Event</div>
              <div style={{ fontSize: 12, color: T.textMid }}>Post a new service event</div>
            </div>
          </div>
        </Card>
        <Card style={{ cursor: "pointer" }} onClick={() => setPage("match")}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 40, height: 40, borderRadius: 8, background: `${T.blue}20`, border: `1px solid ${T.blue}40`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon d={Icons.bolt} size={18} stroke={T.blue} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500 }}>Match Suppliers</div>
              <div style={{ fontSize: 12, color: T.textMid }}>Find providers near you</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

// ─── CREATE EVENT FLOW ────────────────────────────────────────────────────────
const EventsPage = ({ setPage, setSelectedEvent }) => {
  const [showCreate, setShowCreate] = useState(false);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: "", date: "", location: "", attendees: "",
    budget: "", needs: [], notes: "",
  });
  const [events, setEvents] = useState(MOCK_EVENTS);
  const [created, setCreated] = useState(false);

  const toggleNeed = (n) => setForm(f => ({
    ...f, needs: f.needs.includes(n) ? f.needs.filter(x => x !== n) : [...f.needs, n],
  }));

  const serviceOptions = ["Tents", "Marquees", "Catering", "Portable Toilets", "Chairs", "Tables", "Floral Décor", "Waiting Staff", "Audio/Visual", "Parking"];

  const handleCreate = () => {
    const newEv = {
      id: `e${Date.now()}`, parlorId: "p1",
      name: form.name || "New Service Event",
      date: form.date, location: form.location,
      attendees: parseInt(form.attendees) || 0,
      needs: form.needs,
      status: "pending", budget: parseInt(form.budget) || 0,
    };
    setEvents(prev => [...prev, newEv]);
    setCreated(true);
    setTimeout(() => { setShowCreate(false); setCreated(false); setStep(1); setForm({ name: "", date: "", location: "", attendees: "", budget: "", needs: [], notes: "" }); }, 1800);
  };

  return (
    <div className="fade-up">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
        <div>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 2 }}>Events</h2>
          <p style={{ color: T.textMid, fontSize: 14 }}>Manage and track all your service events.</p>
        </div>
        <Btn onClick={() => setShowCreate(true)} icon={<Icon d={Icons.plus} size={15} />}>New Event</Btn>
      </div>

      {/* Events list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {events.map(ev => (
          <Card key={ev.id} style={{ cursor: "pointer" }}
            onClick={() => { setSelectedEvent(ev); setPage("match"); }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 10,
                background: ev.status === "confirmed" ? T.greenDim : T.accentGlow,
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}>
                <Icon d={Icons.calendar} size={20} stroke={ev.status === "confirmed" ? T.green : T.accent} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 4 }}>{ev.name}</div>
                <div style={{ display: "flex", gap: 12, fontSize: 12, color: T.textMid }}>
                  <span>📅 {ev.date}</span>
                  <span>📍 {ev.location}</span>
                  <span>👥 {ev.attendees} guests</span>
                </div>
                <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                  {ev.needs.map(n => <Badge key={n} color={T.textMid} bg={T.border}>{n}</Badge>)}
                </div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <Badge color={ev.status === "confirmed" ? T.green : T.accent}>{ev.status}</Badge>
                <div style={{ fontSize: 14, fontWeight: 600, color: T.text, marginTop: 6, fontFamily: "'DM Mono', monospace" }}>
                  R{ev.budget.toLocaleString()}
                </div>
                <div style={{ fontSize: 11, color: T.textMid }}>budget</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Create modal */}
      {showCreate && (
        <div className="fade-in" style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)",
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 100, padding: 24,
        }}>
          <Card className="fade-up" style={{ width: "100%", maxWidth: 520, maxHeight: "90vh", overflowY: "auto" }}>
            {created ? (
              <div style={{ textAlign: "center", padding: "32px 0" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>✓</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 600, color: T.green }}>Event Created</div>
                <div style={{ color: T.textMid, marginTop: 8, fontSize: 14 }}>Redirecting to supplier matching…</div>
              </div>
            ) : (
              <>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 600 }}>New Event</h3>
                    <p style={{ color: T.textMid, fontSize: 12 }}>Step {step} of 2</p>
                  </div>
                  <button onClick={() => setShowCreate(false)} style={{ background: "none", border: "none", color: T.textMid }}>
                    <Icon d={Icons.x} size={18} />
                  </button>
                </div>

                {/* Progress */}
                <div style={{ display: "flex", gap: 4, marginBottom: 24 }}>
                  {[1, 2].map(s => (
                    <div key={s} style={{ flex: 1, height: 3, borderRadius: 2, background: s <= step ? T.accent : T.border, transition: "background 0.3s" }} />
                  ))}
                </div>

                {step === 1 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                    <Input label="Event Name" value={form.name} onChange={v => setForm(f => ({ ...f, name: v }))} placeholder="e.g. Memorial – J. Khumalo" required />
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      <Input label="Date" type="date" value={form.date} onChange={v => setForm(f => ({ ...f, date: v }))} required />
                      <Input label="Expected Attendees" type="number" value={form.attendees} onChange={v => setForm(f => ({ ...f, attendees: v }))} placeholder="80" />
                    </div>
                    <Input label="Venue / Location" value={form.location} onChange={v => setForm(f => ({ ...f, location: v }))} placeholder="Suburb, City" required />
                    <Input label="Total Budget (ZAR)" type="number" value={form.budget} onChange={v => setForm(f => ({ ...f, budget: v }))} placeholder="15000" />
                    <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
                      <Btn variant="secondary" onClick={() => setShowCreate(false)}>Cancel</Btn>
                      <Btn onClick={() => setStep(2)}>Next <Icon d={Icons.arrow} size={14} /></Btn>
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                    <div>
                      <label style={{ fontSize: 12, color: T.textMid, letterSpacing: "0.05em", textTransform: "uppercase", display: "block", marginBottom: 10 }}>
                        Services Required <span style={{ color: T.accent }}>*</span>
                      </label>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                        {serviceOptions.map(s => {
                          const active = form.needs.includes(s);
                          return (
                            <button key={s} onClick={() => toggleNeed(s)} style={{
                              padding: "6px 14px", borderRadius: 6, fontSize: 12, fontWeight: 500,
                              background: active ? T.accentGlow : T.bg,
                              color: active ? T.accent : T.textMid,
                              border: `1px solid ${active ? T.accent + "60" : T.border}`,
                              transition: "all 0.15s",
                            }}>{s}</button>
                          );
                        })}
                      </div>
                    </div>
                    <div>
                      <label style={{ fontSize: 12, color: T.textMid, letterSpacing: "0.05em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Additional Notes</label>
                      <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                        placeholder="Any special requirements or preferences…"
                        rows={3}
                        style={{
                          width: "100%", background: T.surfaceHover, border: `1px solid ${T.borderLight}`,
                          borderRadius: 8, padding: "10px 14px", color: T.text, fontSize: 13,
                          outline: "none", resize: "vertical", fontFamily: "'DM Sans', sans-serif",
                        }} />
                    </div>
                    <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
                      <Btn variant="secondary" onClick={() => setStep(1)}>Back</Btn>
                      <Btn onClick={handleCreate} disabled={form.needs.length === 0}>
                        Create Event <Icon d={Icons.check} size={14} />
                      </Btn>
                    </div>
                  </div>
                )}
              </>
            )}
          </Card>
        </div>
      )}
    </div>
  );
};

// ─── SUPPLIER MATCHING ────────────────────────────────────────────────────────
const MatchPage = ({ selectedEvent, setSelectedEvent }) => {
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [bookingDone, setBookingDone] = useState(null);
  const [filterService, setFilterService] = useState("All");
  const [showPayment, setShowPayment] = useState(false);
  const [payStep, setPayStep] = useState(1);
  const [cardNo, setCardNo] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");

  const services = ["All", "Tents", "Catering", "Portable Toilets", "Chairs", "Floral Décor"];
  const filtered = MOCK_SUPPLIERS.filter(s =>
    filterService === "All" || s.services.some(sv => sv.includes(filterService))
  );

  const handleBook = () => {
    setPayStep(1); setShowPayment(true);
  };

  const handlePay = () => {
    setPayStep(2);
    setTimeout(() => {
      setShowPayment(false);
      setBookingDone(selectedSupplier);
      setSelectedSupplier(null);
    }, 1600);
  };

  return (
    <div className="fade-up">
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 2 }}>Find Suppliers</h2>
        <p style={{ color: T.textMid, fontSize: 14 }}>Auto-matched to your area. Sorted by distance.</p>
      </div>

      {/* Event context bar */}
      {selectedEvent && (
        <Card style={{ marginBottom: 20, padding: 16, background: T.accentGlow, borderColor: T.accent + "40" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Icon d={Icons.bolt} size={18} stroke={T.accent} />
            <div style={{ flex: 1, fontSize: 13 }}>
              Matching suppliers for: <strong style={{ color: T.accent }}>{selectedEvent.name}</strong> — {selectedEvent.date}, {selectedEvent.location}
            </div>
            <button onClick={() => setSelectedEvent(null)} style={{ background: "none", border: "none", color: T.textMid }}>
              <Icon d={Icons.x} size={16} />
            </button>
          </div>
        </Card>
      )}

      {/* Booked confirmation */}
      {bookingDone && (
        <Card style={{ marginBottom: 20, padding: 16, background: T.greenDim, borderColor: T.green + "40" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Icon d={Icons.check} size={18} stroke={T.green} />
            <div style={{ fontSize: 13 }}>
              Booking confirmed with <strong style={{ color: T.green }}>{bookingDone.name}</strong>. A confirmation has been sent to both parties.
            </div>
            <button onClick={() => setBookingDone(null)} style={{ background: "none", border: "none", color: T.textMid }}>
              <Icon d={Icons.x} size={16} />
            </button>
          </div>
        </Card>
      )}

      {/* Filter pills */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {services.map(s => (
          <button key={s} onClick={() => setFilterService(s)} style={{
            padding: "6px 14px", borderRadius: 99, fontSize: 12, fontWeight: 500,
            background: filterService === s ? T.accent : T.surface,
            color: filterService === s ? "#0D0F0E" : T.textMid,
            border: `1px solid ${filterService === s ? T.accent : T.border}`,
            transition: "all 0.15s",
          }}>{s}</button>
        ))}
      </div>

      {/* Supplier cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map(sup => (
          <Card key={sup.id} style={{ cursor: "pointer", transition: "border-color 0.2s, background 0.2s" }}
            onClick={() => setSelectedSupplier(sup)}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
              <div style={{
                width: 50, height: 50, borderRadius: 10, background: T.bg,
                border: `1px solid ${T.border}`, display: "flex", alignItems: "center",
                justifyContent: "center", fontFamily: "'DM Mono', monospace", fontSize: 14,
                color: T.accent, fontWeight: 600, flexShrink: 0,
              }}>{sup.avatar}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                  <span style={{ fontSize: 15, fontWeight: 500 }}>{sup.name}</span>
                  {!sup.available && <Badge color={T.red}>Unavailable</Badge>}
                  {sup.available && <Badge color={T.green}>Available</Badge>}
                </div>
                <div style={{ fontSize: 12, color: T.textMid, marginBottom: 8 }}>{sup.description}</div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {sup.services.map(s => <Badge key={s} color={T.textMid} bg={T.border}>{s}</Badge>)}
                </div>
              </div>
              <div style={{ textAlign: "right", flexShrink: 0 }}>
                <div style={{ fontSize: 13, color: T.accent, fontFamily: "'DM Mono', monospace", fontWeight: 600 }}>
                  R{sup.priceFrom.toLocaleString()}+
                </div>
                <div style={{ fontSize: 11, color: T.textMid, marginBottom: 6 }}>from / event</div>
                <div style={{ fontSize: 12, color: T.textMid }}>⭐ {sup.rating} ({sup.reviews})</div>
                <div style={{ fontSize: 11, color: T.textDim, marginTop: 2 }}>📍 {sup.distance}km away</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Supplier detail panel */}
      {selectedSupplier && (
        <div className="fade-in" style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)",
          display: "flex", alignItems: "flex-end", justifyContent: "flex-end",
          zIndex: 100, padding: 24,
        }}>
          <Card className="fade-up" style={{ width: 380, maxHeight: "85vh", overflowY: "auto" }}>
            <button onClick={() => setSelectedSupplier(null)} style={{ position: "absolute", top: 16, right: 16, background: "none", border: "none", color: T.textMid }}>
              <Icon d={Icons.x} size={18} />
            </button>

            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
              <div style={{
                width: 54, height: 54, borderRadius: 12, background: T.accentGlow,
                border: `1px solid ${T.accent}40`, display: "flex", alignItems: "center",
                justifyContent: "center", fontFamily: "'DM Mono', monospace", fontSize: 16,
                color: T.accent, fontWeight: 600,
              }}>{selectedSupplier.avatar}</div>
              <div>
                <div style={{ fontSize: 17, fontWeight: 600 }}>{selectedSupplier.name}</div>
                <div style={{ fontSize: 12, color: T.textMid }}>{selectedSupplier.area}</div>
              </div>
            </div>

            <p style={{ fontSize: 13, color: T.textMid, marginBottom: 20, lineHeight: 1.7 }}>{selectedSupplier.description}</p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
              <Stat label="Rating" value={selectedSupplier.rating} />
              <Stat label="Reviews" value={selectedSupplier.reviews} />
              <Stat label="Distance" value={`${selectedSupplier.distance}km`} />
            </div>

            <Divider style={{ marginBottom: 20 }} />

            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, color: T.textMid, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 10 }}>Services Offered</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {selectedSupplier.services.map(s => <Badge key={s} color={T.accent}>{s}</Badge>)}
              </div>
            </div>

            <div style={{ background: T.accentGlow, border: `1px solid ${T.accent}30`, borderRadius: 10, padding: "12px 16px", marginBottom: 20 }}>
              <div style={{ fontSize: 11, color: T.accent, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4 }}>Starting Price</div>
              <div style={{ fontSize: 24, fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, color: T.text }}>
                R{selectedSupplier.priceFrom.toLocaleString()} <span style={{ fontSize: 14, color: T.textMid }}>/event</span>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="secondary" style={{ flex: 1, justifyContent: "center" }}>Message</Btn>
              <Btn style={{ flex: 1, justifyContent: "center" }} disabled={!selectedSupplier.available} onClick={handleBook}>
                Book Now
              </Btn>
            </div>
          </Card>
        </div>
      )}

      {/* Payment modal */}
      {showPayment && (
        <div className="fade-in" style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)",
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 200, padding: 24,
        }}>
          <Card className="fade-up" style={{ width: "100%", maxWidth: 420 }}>
            {payStep === 2 ? (
              <div style={{ textAlign: "center", padding: "28px 0" }}>
                <div style={{ fontSize: 42, marginBottom: 12, animation: "pulse 1s ease" }}>✓</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 600, color: T.green }}>Payment Processing…</div>
              </div>
            ) : (
              <>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 600 }}>Secure Payment</h3>
                    <p style={{ fontSize: 12, color: T.textMid }}>via PayFast · SSL Encrypted</p>
                  </div>
                  <button onClick={() => setShowPayment(false)} style={{ background: "none", border: "none", color: T.textMid }}>
                    <Icon d={Icons.x} size={18} />
                  </button>
                </div>

                {selectedSupplier && (
                  <div style={{ background: T.bg, borderRadius: 8, padding: 14, marginBottom: 20 }}>
                    <div style={{ fontSize: 13, color: T.textMid, marginBottom: 4 }}>Booking summary</div>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{selectedSupplier.name}</div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 14 }}>
                      <span style={{ color: T.textMid }}>Deposit (50%)</span>
                      <span style={{ fontFamily: "'DM Mono', monospace", color: T.accent }}>R{(selectedSupplier.priceFrom / 2).toLocaleString()}</span>
                    </div>
                  </div>
                )}

                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <Input label="Card Number" value={cardNo} onChange={setCardNo} placeholder="4242 4242 4242 4242" />
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <Input label="Expiry" value={expiry} onChange={setExpiry} placeholder="MM / YY" />
                    <Input label="CVV" value={cvv} onChange={setCvv} placeholder="123" />
                  </div>
                  <Btn onClick={handlePay} style={{ width: "100%", justifyContent: "center", marginTop: 4 }}
                    icon={<Icon d={Icons.credit} size={15} />}>
                    Pay R{selectedSupplier ? (selectedSupplier.priceFrom / 2).toLocaleString() : "–"} Deposit
                  </Btn>
                </div>
              </>
            )}
          </Card>
        </div>
      )}
    </div>
  );
};

// ─── BOOKINGS PAGE ────────────────────────────────────────────────────────────
const BookingsPage = ({ user }) => {
  const isSupplier = user?.type === "supplier";
  const bookings = [
    { id: "b1", event: "Memorial – M. Dlamini", supplier: "Prestige Tents & Marquees", parlor: "Serenity Funeral Home", date: "2025-03-22", amount: 3500, status: "confirmed", paid: true },
    { id: "b2", event: "Memorial – M. Dlamini", supplier: "Grace Catering Co.", parlor: "Serenity Funeral Home", date: "2025-03-22", amount: 8000, status: "confirmed", paid: true },
    { id: "b3", event: "Graveside Service – T. Mokoena", supplier: "Serenity Chairs & Tables", parlor: "Serenity Funeral Home", date: "2025-03-29", amount: 2200, status: "pending", paid: false },
  ];

  return (
    <div className="fade-up">
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 2 }}>Bookings</h2>
        <p style={{ color: T.textMid, fontSize: 14 }}>Track confirmed and pending service agreements.</p>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {bookings.map(b => (
          <Card key={b.id}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{
                width: 46, height: 46, borderRadius: 10, flexShrink: 0,
                background: b.status === "confirmed" ? T.greenDim : T.accentGlow,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <Icon d={b.status === "confirmed" ? Icons.check : Icons.calendar} size={20}
                  stroke={b.status === "confirmed" ? T.green : T.accent} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 2 }}>
                  {isSupplier ? b.event : b.supplier}
                </div>
                <div style={{ fontSize: 12, color: T.textMid }}>
                  {isSupplier ? `${b.parlor} · ` : ""}{b.date}
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 15, fontWeight: 600, marginBottom: 4 }}>
                  R{b.amount.toLocaleString()}
                </div>
                <Badge color={b.paid ? T.green : T.accent}>{b.paid ? "Paid" : "Pending Payment"}</Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card style={{ marginTop: 24, padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ color: T.textMid, fontSize: 14 }}>Total confirmed spend</span>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 20, fontWeight: 600, color: T.accent }}>
            R{bookings.filter(b => b.paid).reduce((s, b) => s + b.amount, 0).toLocaleString()}
          </span>
        </div>
      </Card>
    </div>
  );
};

// ─── SUPPLIER LISTINGS PAGE ───────────────────────────────────────────────────
const ListingsPage = ({ user }) => {
  const supplier = MOCK_SUPPLIERS.find(s => s.id === "s1") || MOCK_SUPPLIERS[0];
  return (
    <div className="fade-up">
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 2 }}>My Listings</h2>
        <p style={{ color: T.textMid, fontSize: 14 }}>Manage your service offerings and availability.</p>
      </div>
      <Card style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
          <div style={{ width: 54, height: 54, borderRadius: 12, background: T.accentGlow, border: `1px solid ${T.accent}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontFamily: "'DM Mono', monospace", color: T.accent, fontWeight: 600 }}>{supplier.avatar}</div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 600 }}>{user.name}</div>
            <div style={{ fontSize: 12, color: T.textMid }}>📍 {supplier.area} · {supplier.distance}km radius</div>
          </div>
          <div style={{ marginLeft: "auto" }}>
            <Badge color={T.green}>Active</Badge>
          </div>
        </div>
        <Divider style={{ marginBottom: 16 }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <Stat label="Rating" value={supplier.rating} />
          <Stat label="Reviews" value={supplier.reviews} />
          <Stat label="From" value={`R${supplier.priceFrom.toLocaleString()}`} accent={T.accent} />
        </div>
      </Card>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {supplier.services.map((s, i) => (
          <Card key={s} style={{ padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 8, height: 8, borderRadius: 4, background: T.accent, flexShrink: 0 }} />
              <span style={{ fontSize: 14, flex: 1 }}>{s}</span>
              <Badge color={T.green}>Available</Badge>
              <Btn small variant="secondary">Edit</Btn>
            </div>
          </Card>
        ))}
      </div>
      <Btn style={{ marginTop: 20 }} variant="secondary" icon={<Icon d={Icons.plus} size={14} />}>Add New Service</Btn>
    </div>
  );
};

// ─── SUPPLIER DASHBOARD ───────────────────────────────────────────────────────
const SupplierDashboard = ({ user }) => (
  <div className="fade-up">
    <div style={{ marginBottom: 32 }}>
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 28, fontWeight: 600, marginBottom: 4 }}>Welcome back, {user.name}</h2>
      <p style={{ color: T.textMid, fontSize: 14 }}>New booking requests are waiting for your response.</p>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }}>
      {[
        { label: "New Requests", value: "3", sub: "This week", accent: T.accent },
        { label: "Active Bookings", value: "2", sub: "In progress", accent: T.green },
        { label: "Monthly Revenue", value: "R24,500", sub: "March 2025", accent: T.text },
      ].map((s, i) => (
        <Card key={i} style={{ padding: 20 }}><Stat {...s} /></Card>
      ))}
    </div>
    <Card>
      <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 600, marginBottom: 16 }}>Incoming Requests</h3>
      {[
        { parlor: "Serenity Funeral Home", event: "Graveside – T. Mokoena", date: "2025-03-29", service: "Tents", budget: "R3,500" },
        { parlor: "Dignity Memorial Services", event: "Memorial – B. Nkosi", date: "2025-04-05", service: "Marquees", budget: "R5,200" },
      ].map((req, i) => (
        <div key={i}>
          {i > 0 && <Divider style={{ margin: "14px 0" }} />}
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 2 }}>{req.parlor}</div>
              <div style={{ fontSize: 12, color: T.textMid }}>{req.event} · {req.date} · {req.service}</div>
            </div>
            <div style={{ fontSize: 14, fontFamily: "'DM Mono', monospace", color: T.accent, marginRight: 12 }}>{req.budget}</div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn small variant="danger">Decline</Btn>
              <Btn small>Accept</Btn>
            </div>
          </div>
        </div>
      ))}
    </Card>
  </div>
);

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [selectedEvent, setSelectedEvent] = useState(null);

  const handleLogin = (u) => { setUser(u); setPage("dashboard"); };
  const handleLogout = () => { setUser(null); setPage("dashboard"); };

  const renderPage = () => {
    if (!user) return null;
    const isSupplier = user.type === "supplier";

    if (page === "dashboard") return isSupplier ? <SupplierDashboard user={user} /> : <ParlorDashboard user={user} setPage={setPage} />;
    if (page === "events" && !isSupplier) return <EventsPage setPage={setPage} setSelectedEvent={setSelectedEvent} />;
    if (page === "match" && !isSupplier) return <MatchPage selectedEvent={selectedEvent} setSelectedEvent={setSelectedEvent} />;
    if (page === "bookings") return <BookingsPage user={user} />;
    if (page === "listings" && isSupplier) return <ListingsPage user={user} />;
    return null;
  };

  if (!user) return (<><GlobalStyle /><AuthScreen onLogin={handleLogin} /></>);

  return (
    <>
      <GlobalStyle />
      <div style={{ display: "flex", minHeight: "100vh" }}>
        <Sidebar user={user} page={page} setPage={setPage} onLogout={handleLogout} />
        <main style={{ flex: 1, marginLeft: 220, padding: 40, maxWidth: "calc(100vw - 220px)" }}>
          {renderPage()}
        </main>
      </div>
    </>
  );
}
